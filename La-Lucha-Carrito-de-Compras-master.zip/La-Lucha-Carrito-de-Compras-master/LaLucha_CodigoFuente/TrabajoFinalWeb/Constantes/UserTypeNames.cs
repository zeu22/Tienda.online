﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Restaurante.Constantes
{
    public class UserTypeNames
    {
        public const string Admin = "admin";
    }
}