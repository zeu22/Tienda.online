﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Restaurante.Constantes
{
    public class SessionName
    {
        public const string User = "user";
    }
}