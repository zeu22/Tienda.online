﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TrabajoFinalWeb.Models.procedures
{
    public class eliminarTodo
    {
    }
}